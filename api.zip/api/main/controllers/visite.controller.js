const visite_model                      = require('../models/visite.model')         ;
const utilisateur_model                 = require('../models/utilisateur.model')    ;
const partenaire_model                  = require('../models/partenaire.model')     ;
const jwt_decode                        = require('jwt-decode')                     ;
const mysql                             = require('mysql')                          ;
const moment                            = require('moment')                         ;
const {validateAccess}                  = require('../../helpers/function.helper')  ;

exports.tab_visites = (req, res) => { 
    const bearer = req.headers.authorization.split(' ')[1];
    let bearer_content = {};
    try {
        bearer_content = jwt_decode(bearer);
    } catch {
        return res.status(400).json({
            error: 'the token is not valid'
        });
    }
    let records_per_page    = parseInt(req.params['records_per_page'], 10) || 1;
    let page_number         = parseInt(req.params['page_number'], 10) || 0;
    let records_to_skip     = page_number * records_per_page;
    let limit               = records_to_skip  + ',' + records_per_page;

    let {
        type_partenaire     ,
        code_specialite     ,
        code_potentiel      ,
        date_debut_visite   ,
        date_fin_visite     ,
        code_statut_visite  ,
        code_region         ,
        nom_partenaire      ,
        id_utilisateur      ,
        order_by            ,
        type_tri 
    } = {...req.body}
    
    let query           = visite_model.que_tab_visites;
    let count_query     = visite_model.que_nbr_tab_visites;

    if(code_potentiel){
        code_potentiel  = code_potentiel.join('\',\'');
        query           += 'AND code_potentiel IN (\'' + code_potentiel + '\')';
        count_query     += 'AND code_potentiel IN (\'' + code_potentiel + '\')';
    }
    if(code_specialite){
        code_specialite = code_specialite.join('\',\'');
        query           += 'AND code_specialite IN (\'' + code_specialite +'\')';
        count_query     += 'AND code_specialite IN (\'' + code_specialite +'\')';
    }


    if(order_by != null) {
        if(order_by == 'nom_partenaire')
            query += ' ORDER BY nom_partenaire '    + (type_tri != null && type_tri == 'ASC' ? type_tri : 'DESC') + ', tpv.date_visite DESC, tpv.id_visite DESC';
        
        else if(order_by == 'date_visite')
            query += ' ORDER BY tpv.date_visite '   + (type_tri != null && type_tri == 'ASC' ? type_tri : 'DESC') + ', tpv.id_visite DESC';
        
        else if(order_by == 'nom_utilisateur')
            query += ' ORDER BY nom_utilisateur '   + (type_tri != null && type_tri == 'ASC' ? type_tri : 'DESC') + ', tpv.date_visite DESC, tpv.id_visite DESC';
            
        else 
            query += ' ORDER BY tpv.date_visite DESC, tpv.id_visite DESC';
    }
    else {
        query += ' ORDER BY tpv.date_visite DESC, tpv.id_visite DESC';
    }

    count_query = mysql.format(count_query,[
        bearer_content.id_utilisateur       ,
        bearer_content.role                 ,
        bearer_content.flag_medical         ,
        bearer_content.flag_pharmaceutique  ,
        type_partenaire                     ,
        date_debut_visite                   ,
        date_fin_visite                     ,
        code_statut_visite                  ,
        code_region                         ,
        nom_partenaire                      ,
        id_utilisateur
    ])

    connection.query(query + ' LIMIT ' + limit + ';' + count_query,[
        bearer_content.id_utilisateur       ,
        bearer_content.role                 ,
        bearer_content.flag_medical         ,
        bearer_content.flag_pharmaceutique  ,
        type_partenaire                     ,
        date_debut_visite                   ,
        date_fin_visite                     ,
        code_statut_visite                  ,
        code_region                         ,
        nom_partenaire                      ,
        id_utilisateur
    ] , (err, result) => {
        if (!err) {
            const response = {
                visites             : result[result.length-3],
                nbr_total_visites   : result[result.length-1][0].nbr_total_visites
            }
            return res.status(200).json(response).end();

        } else {
            return res.status(500).json(err);
        }
    })
}

exports.tab_accompagnants = (req, res) => { 
    const bearer = req.headers.authorization.split(' ')[1];
    let bearer_content = {};
    try {
        bearer_content = jwt_decode(bearer);
    } catch {
        return res.status(400).json({
            error: 'the token is not valid'
        });
    }

    connection.query(visite_model.que_tab_accompagnants,[
        bearer_content.id_utilisateur       ,
        bearer_content.role                 ,
        bearer_content.flag_medical         ,
        bearer_content.flag_pharmaceutique
    ], (err, result) => {
        if (!err) {
            return res.status(200).json({accompagnants : result[result.length-1]}).end();
        } else {
            return res.status(500).json(err);
        }
    })
}

exports.tab_gamme_produits = (req, res) => { 
    const bearer = req.headers.authorization.split(' ')[1];
    let bearer_content = {};
    try {
        bearer_content = jwt_decode(bearer);
    } catch {
        return res.status(400).json({
            error: 'the token is not valid'
        });
    }

    connection.query(visite_model.que_tab_gammes_produits,[
        bearer_content.id_utilisateur       ,
        bearer_content.role                 ,
        bearer_content.flag_medical         ,
        bearer_content.flag_pharmaceutique
    ], (err, result) => {
        if (!err) {
            let liste_gammes     = result[result.length-2];
            let liste_produits   = result[result.length-1];

            liste_gammes.forEach(gamme => {
                gamme['produits'] = [];
                liste_produits.forEach(produit => {
                    if(gamme.code_codification == produit.code_gamme){
                        gamme['produits'].push(produit);
                    }
                })
            });

            return res.status(200).json({gammes : liste_gammes }).end();
        } else {
            return res.status(500).json(err);
        }
    })
}

exports.tab_feedbacks = (req, res) => { 
    const bearer = req.headers.authorization.split(' ')[1];
    let bearer_content = {};
    try {
        bearer_content = jwt_decode(bearer);
    } catch {
        return res.status(400).json({
            error: 'the token is not valid'
        });
    }
    
    connection.query(visite_model.que_tab_feedbacks, (err, result) => {
        if (!err) {
            return res.status(200).json({feedbacks : result}).end();
        } else {
            return res.status(500).json(err);
        }
    })
}

exports.ajouter_visite = (req, res) => { 
    const bearer = req.headers.authorization.split(' ')[1];
    let bearer_content = {};
    try {
        bearer_content = jwt_decode(bearer);
    } catch {
        return res.status(400).json({
            error: 'the token is not valid'
        });
    }

    const roles = ['DIR','DRG','PM','DSM','KAM','DEL'];
    if(!validateAccess(roles, bearer_content.role)){
        return res.status(200).json({message : "Sorry, you're not authorized to use this API"}).end();
    }

    let {
        id_partenaire       ,
        date_visite         ,
        code_statut_visite  ,
        commentaire         ,
        flag_accompagnee    ,
        id_accompagnant     ,
        produits
    } = {...req.body}
    
    let bulk_query = ' ';
    let bulk_array = [] ;

    bulk_query += visite_model.que_add_visite;
    bulk_array.push(
        bearer_content.id_utilisateur       ,
        bearer_content.role                 ,
        bearer_content.flag_medical         ,
        bearer_content.flag_pharmaceutique  ,
        id_partenaire                       ,
        code_statut_visite                  ,
        commentaire                         ,
        flag_accompagnee                    ,
        id_accompagnant                     ,
        date_visite
    );
    let query_infos = mysql.format(partenaire_model.que_get_infos_partenaire,[id_partenaire]);

    connection.query(bulk_query + query_infos, bulk_array, (err, result) => {
        if (!err) {

            if (result[result.length-3][0].done == 'ko') {
                return res.status(500).send({message : "Sorry, you're not authorized to use this API"});
            }

            let id_visite       = result[result.length - 5][0].id_visite            ;
            let nom_partenaire  = result[result.length - 1][0].nom_partenaire       ;
            let date            = moment(new Date(date_visite)).format("DD-MM-YYYY");

            let query_historique = mysql.format(utilisateur_model.que_add_historique_utilisateur,[
                bearer_content.id_utilisateur   , 
                "Ajout d'une visite hors planification effectuée le " + date + " chez le partenaire : " + nom_partenaire
            ]);

            connection.query(query_historique, (err, result) => {
                if (!err) {
                    if (produits && produits.length > 0 && code_statut_visite == 'REAL') {
                        produits.forEach(produit => {
                            try{
                                produit.unshift(id_visite);
                            }
                            catch(err)
                            {
                                return res.status(400).json({error : "data sent is bad in produit."});
                            }
                        });
                        connection.query(visite_model.que_add_visite_produit, [produits], (err) => {
                            if (err) {
                                return res.status(500).json(err).end();
                            } else {
                                return res.status(200).json({id_visite}).end();
                            }
                        });
                    }
                    else
                        return res.status(200).json({id_visite}).end();
                }
                else {
                    return res.status(500).json(err);
                }
            })
        } else {
            if(err.code==='ER_DUP_ENTRY'){
                return res.status(200).json({visite:result[result.length - 1][0],duplicate:true});
            }
            return res.status(500).json(err);
        }
    })
}

exports.fiche_visite = (req, res) => { 
    const bearer = req.headers.authorization.split(' ')[1];
    let bearer_content = {};
    try {
        bearer_content = jwt_decode(bearer);
    } catch {
        return res.status(400).json({
            error: 'the token is not valid'
        });
    }

    let { id_visite } = {...req.params}
    
    connection.query(visite_model.que_fiche_visite,[
        bearer_content.id_utilisateur   ,
        bearer_content.role             ,
        id_visite
    ], (err, result) => {
        if (!err) {
            let visite = result[result.length-2];

            if(!visite.length){
                return res.status(200).json({ flag_non_disponible : 'O' }).end();
            }

            visite[0]['produits'] = result[result.length-1];
            return res.status(200).json({ visite : visite[0] }).end();
        } else {
            return res.status(500).json(err);
        }
    })
}

exports.modifier_visite = (req, res) => { 
    const bearer = req.headers.authorization.split(' ')[1];
    let bearer_content = {};
    try {
        bearer_content = jwt_decode(bearer);
    } catch {
        return res.status(400).json({
            error: 'the token is not valid'
        });
    }

    const roles = ['DIR','DRG','PM','DSM','KAM','DEL'];
    if(!validateAccess(roles, bearer_content.role)){
        return res.status(200).json({message : "Sorry, you're not authorized to use this API"}).end();
    }

    let {
        id_visite           ,
        id_partenaire       ,
        code_potentiel      ,
        date_visite         ,
        id_planification    ,
        date_replanification,
        code_type_visite    ,
        code_statut_visite  ,
        commentaire         ,
        flag_accompagnee    ,
        id_accompagnant     ,
        produits
    } = {...req.body}
    
    let bulk_query = ' ';
    let bulk_array = [] ;

    bulk_query += visite_model.que_upd_visite;
    bulk_array.push(
        bearer_content.id_utilisateur   ,
        bearer_content.role             ,
        id_visite                       ,
        id_planification                ,
        id_partenaire                   ,
        code_potentiel                  ,
        date_visite                     ,
        date_replanification            ,
        code_type_visite                ,
        code_statut_visite              ,
        commentaire                     ,
        flag_accompagnee                ,
        id_accompagnant
    );

    if((code_type_visite == 'HOPL' && (code_statut_visite == 'ABSE' || code_statut_visite == 'REAL')) || code_type_visite == 'PLAN'){
        bulk_query += visite_model.que_delete_visite_produit;
        bulk_array.push(id_visite);
    }
    
    let query_infos = mysql.format(partenaire_model.que_get_infos_partenaire,[id_partenaire]);

    connection.query(bulk_query + query_infos, bulk_array, (err, result) => {
        if (!err) {

            let id_new_visite       = result[result.length - 4][0].id_visite            ;
            let done                = result[result.length - 4][0].done                 ;
            let nom_partenaire      = result[result.length - 1][0].nom_partenaire       ;
            let date                = moment(new Date(date_visite)).format("DD-MM-YYYY");

            let query_historique    = mysql.format(utilisateur_model.que_add_historique_utilisateur,[
                bearer_content.id_utilisateur   , 
                "Modification de la visite du " + date + " chez le partenaire : " + nom_partenaire
            ]);

            if(id_new_visite == 0) {
                return res.status(200).json({duplicate:true,error:'This partner is already planned for the selected week'});
            }
            
            connection.query(query_historique, (err, result) => {
                if(!err){
                    if (done == 'ok' && produits && produits.length && code_statut_visite == 'REAL') {
                        produits.forEach(produit => {
                            try{
                                produit.unshift(id_new_visite);
                            }
                            catch(err)
                            {
                                return res.status(400).json({error : "data sent is bad in produit."});
                            }
                        });
                        
                        connection.query(visite_model.que_add_visite_produit, [produits], (err) => {
                            if (err) {
                                return res.status(500).json(err).end();
                            } else {
                                return res.status(200).json({id_visite : id_new_visite}).end();
                            }
                        });
                    }
                    else
                        return res.status(200).json({id_visite : id_new_visite}).end();
                }
                else{
                    return res.status(500).json(err);
                }
            })
        } else {
            if(err.code==='ER_DUP_ENTRY'){
                return res.status(200).json({duplicate:true,error:'This partner is already planned for the selected week'});
            }
            return res.status(500).json(err);
        }
    })
}