module.exports = {
    que_authentification: `
        SELECT 
            telephone                   ,  
            nom_utilisateur             ,  
            prenom_utilisateur          ,
            CONCAT(nom_utilisateur,' ',prenom_utilisateur) AS nom_prenom,
            id_utilisateur              ,  
            code_statut_utilisateur     ,
            role                        ,
            login                       ,
            flag_medical                ,
            flag_pharmaceutique

        FROM    tab_utilisateur
        WHERE   login                     = ?
        AND     password                  = md5(?)
        AND     code_statut_utilisateur   = 'ACTI';
    `,

    que_activation_utilisateur: `
        SELECT  code_statut_utilisateur
        FROM    tab_utilisateur
        WHERE   id_utilisateur = ?;
    `

}